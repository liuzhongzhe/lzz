<template>
	<div class="tab_wrapper">
		<div class="tab" id="tab">
			<div class="logo" style="width: 160px;height: 50px;margin: 0 auto;margin-bottom: 50px;">
				<img src="../../static/logo2.png" width="100px" height="43px" style="margin-left: 20px;"/>
				<p style="margin: 0 auto; text-align: center; font-size: 14px; width: 160px; color: #FFFFFF; display: block;border-top: 1px solid #FFFFFF;">配煤掺烧燃烧仿真系统</p>
			</div>
			<Col>
			<Menu :active-name="navIndex" @on-select="selectTab" :open-names="navIndex">
				<MenuItem name="1">
				<Icon type="ios-briefcase"></Icon>
				个人工作台
				</MenuItem>
				<Submenu name="2">
					<template slot="title">
						<Icon type="android-apps"></Icon>
						燃烧仿真
					</template>
					<MenuItem name="2-1">计算任务</MenuItem>
					<MenuItem name="2-2">仿真计算</MenuItem>
					<MenuItem name="2-3">结果处理</MenuItem>
				</Submenu>
				<Submenu name="3">
					<template slot="title">
						<Icon type="android-apps"></Icon>
						配煤掺烧
					</template>
					<MenuItem name="3-1">掺烧方案
					</MenuItem>
					<MenuItem name="3-2">采购方案
					</MenuItem>
				</Submenu>
				<Submenu name="4">
					<template slot="title">
						<Icon type="android-apps"></Icon>
						配置管理
					</template>
					<MenuItem name="4-1">燃烧仿真配置
					</MenuItem>
					<MenuItem name="4-2">配媒掺烧配置
					</MenuItem>
				</Submenu>
				<Submenu name="7">
					<template slot="title">
						<Icon type="gear-a"></Icon>
						系统管理
					</template>
					<MenuItem name="7-1">用户管理</MenuItem>
					<MenuItem name="7-2">角色设置</MenuItem>
					<MenuItem name="7-3">权限控制</MenuItem>
				</Submenu>
			</Menu>
			</Col>
			<div class="user">
				<img src="../assets/logo.png" @click="viewUserInfo" />
				<p style="color: #FFFFFF;">UserName</p>
				<div v-show="userSetShow" style="transition: .5s;">
					<p @click="userSet">用户设置</p>
					<p @click="exitLogon">退出登录</p>
				</div>
			</div>
		</div>
	</div>
</template>

<script>
	export default {
		data() {
			return {
				userInfoShow: true,
				userSetShow: false
			}
		},
		props: {
			navIndex: {
				type: String
			}
		},
		mounted() {
			console.log(this.navIndex)
		},
		methods: {
			viewUserInfo() {
				this.userSetShow = true
				setTimeout(() => {
					this.userSetShow = false
				}, 2000)
			},
			exitLogon() {
				this.$router.push('/login');
			},
			userSet() {
				this.$router.push('/user_set');
			},
			selectTab(key) {
				console.log(key)
				switch(key) {
					case '1':
						this.$router.push('/personal_work');
						break;
					case '2-1':
						this.$router.push('/sim_app_system');
						break;
					case '3-1':
						this.$router.push('/sim_task_man');
						break;
					case '4-1':
						this.$router.push('/sim_material_lib');
						break;
						//					case '4-2':
						//						this.$router.push('/sim_material_lib');
						//						break;
						//					case '4-3':
						//						this.$router.push('/calculat_manage');
						//						break;
					case '7-1':
						this.$router.push('/user_manage');
						break;
						//					case '7-2':
						//						this.$router.push('/role_set');
						//						break;

				}
			},
		}
	}
</script>

<style lang="scss" scoped="scoped">
	.tab_wrapper {
		width: 230px;
		background: rgb(47, 117, 178);
		font-size: 14px;
		.ivu-menu-light {
			background: rgb(47, 117, 178);
			width: 230px !important;
		}
		.ivu-menu-vertical.ivu-menu-light:after {
			display: none !important;
		}
		/deep/ .ivu-menu-vertical .ivu-menu-submenu-title:hover {
			background: #fe5815 !important;
			color: #FFFFFF !important;
		}
		/deep/ .ivu-menu-vertical .ivu-menu-item:hover,
		.ivu-menu-vertical .ivu-menu-submenu-title:hover,
		.ivu-menu-light.ivu-menu-vertical .ivu-menu-item-active:not(.ivu-menu-submenu) {
			background: #fe5815 !important;
			color: #FFFFFF !important;
			border-right: none;
		}
		.ivu-menu,
		.ivu-menu-light.ivu-menu-vertical .ivu-menu-item {
			color: #FFFFFF;
		}
		>.tab {
			>.logo {
				padding: 40px 0;
				margin: 0 auto;
				span {
					display: block;
					text-align: center;
					border-top: 1px solid #FFFFFF;
					color: #ffffff;
					font-size: 14px;
					height: 34px;
					line-height: 34px;
				}
			}
			>.user {
				position: fixed;
				left: 89px;
				bottom: 20px;
				text-align: center;
				margin-top: 50px;
				color: #FFFFFF;
				img {
					width: 39px;
					height: 39px;
					border-radius: 50%;
					padding: 5px;
					border: 1px solid rgba(255, 255, 255, 0.1);
					cursor: pointer;
				}
				>p {
					font-size: 12px;
					color: rgb(122, 126, 138);
					margin-top: 2px;
				}
				div {
					margin-top: 10px;
					p {
						cursor: pointer;
						line-height: 25px;
					}
				}
			}
		}
	}
</style>