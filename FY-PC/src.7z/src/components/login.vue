<template>
	<div class="login">
		<div class="box">
			<el-tree ref="tree" :data="data2" show-checkbox node-key="id" :default-expanded-keys="[2, 3]" :default-checked-keys="[5,6]" :props="defaultProps">
			</el-tree>
			 <el-button @click="getCheckedNodes">通过 node 获取</el-button>
			<!-- <div class="logo">
				<img src="../../static/logo2.png" style="width: 100px;height: 43px; margin: 10px;" />
			</div>
			<div class="content">
				<span>配煤掺烧燃烧仿真系统</span>
			</div>
			<div class="inp">
				<div class="sec">
					<span>用户名</span>
					<i-input></i-input>
				</div>
				<div class="sec" style="margin-top: 20px;">
					<span>密码</span>
					<i-input></i-input>
				</div>
			</div>
			<div class="button">
				<i-button type="warning" @click="toLogin">登陆</i-button>
			</div> -->
		</div>
	</div>
</template>
<script>
	export default {
		data() {
			return {
				numAr: Array,
				ar2: Array,
				obj1: {
					name: 'lzz'
				},
				data2: [{
					id: 1,
					label: '一级 1',
					children: [{
						id: 4,
						label: '二级 1-1',
						children: [{
							id: 9,
							label: '三级 1-1-1'
						}, {
							id: 10,
							label: '三级 1-1-2'
						}]
					}]
				}, {
					id: 2,
					label: '一级 2',
					children: [{
						id: 5,
						label: '二级 2-1'
					}, {
						id: 6,
						label: '二级 2-2'
					}]
				}, {
					id: 3,
					label: '一级 3',
					children: [{
						id: 7,
						label: '二级 3-1'
					}, {
						id: 8,
						label: '二级 3-2'
					}]
				}],
				defaultProps: {
					children: 'children',
					label: 'label'
				}
			};
		},
		filters: {

		},
		mounted() {
			let a = "abc de"
			let b = [...a]
			console.log(b.reverse().join(''));
		},
		methods: {
			 getCheckedNodes() {
        console.log(this.$refs.tree.getCheckedKeys());
      },
			toLogin() {
				this.$router.push('/personal_work')
			}
		}
	};
</script>
<style lang="scss" scoped="scoped">
	.login {
		width: 100%;
		height: 100%;
		background: rgb(47, 117, 178);
		position: relative;
		>.box {
			background: rgba(255, 255, 255, 0.7);
			width: 500px;
			height: 320px;
			border-radius: 20px;
			margin: -160px 0 0 -250px;
			position: absolute;
			left: 50%;
			top: 50%;
			z-index: 100;
			>.content {
				height: 40px;
				text-align: center;
				position: relative;
				z-index: 100;
				margin: 20px 0px 30px;
				>span {
					font-size: 20px;
					font-weight: 700;
				}
			}
			>.inp {
				padding: 0 110px 0 85px;
				>.sec {
					span {
						display: inline-block;
						width: 40px;
						text-align: right;
						margin-right: 10px;
					}
					>.ivu-input-wrapper {
						display: inline-block;
						width: 240px;
					}
				}
			}
			>.button {
				width: 120px;
				margin: 20px auto;
				>.ivu-btn-warning {
					width: 120px;
				}
			}
		}
	}
</style>
