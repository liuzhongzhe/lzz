export  const Resource = [
	['background','res/background.png'],
	['land','res/land.png'],
	['pie_up','res/pie_up.png'],
	['pie_down','res/pie_down.png'],
	['birds','res/birds.png'],
	['start_button','res/start_button.png'],
];
