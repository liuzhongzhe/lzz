//下半部分铅笔
export  class DownPencil{
	
}
