//不断移动的陆地
export  class Land{
	
}
