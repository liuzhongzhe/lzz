//上半部分铅笔
export  class UpPencil{
	
}
