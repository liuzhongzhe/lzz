export  class Score{
	
}
